/* $OpenBSD: version.h,v 1.100 2023/12/18 14:48:44 djm Exp $ */

#define SSH_VERSION	"OpenSSH_9.6"
